/*
 * scope.h
 *
 *  Created on: Aug 12, 2012, modified 9/8/2017
 *      Author: Sam Comeau and Will Schwartz
 *
 *  for lab1 creating an oscilloscope
 */

#ifndef SCOPE_H_
#define SCOPE_H_

#include <stdint.h>

#define ADC_SAMPLING_RATE 1000000   // [samples/sec] desired ADC sampling rate
#define CRYSTAL_FREQUENCY 25000000  // [Hz] crystal oscillator frequency used to calculate clock rates

#define ADC_BUFFER_SIZE 2048 // size must be a power of 2
#define ADC_BUFFER_WRAP(i) ((i) & (ADC_BUFFER_SIZE - 1)) // index wrapping macro

extern volatile int32_t gADCBufferIndex; // latest sample index
extern volatile uint16_t gADCBuffer[ADC_BUFFER_SIZE]; // circular buffer

// initialize all button and joystick handling hardware
void ADCInit(void);


#endif /* SCOPE_H_ */
