/**
 * main.c
 *
 * ECE 3849 Lab 0 Starter Project
 * Gene Bogdanov    10/18/2017
 *
 * This version is using the new hardware for B2017: the EK-TM4C1294XL LaunchPad with BOOSTXL-EDUMKII BoosterPack.
 *
 */

#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "driverlib/fpu.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include <math.h>
#include "buttons.h"
#include "scope.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"


#define LOCO_BUFFER_SIZE 128 // size must be a power of 2
#define VIN_RANGE 3.3
#define PIXELS_PER_DIV 20
#define ADC_BITS 12
#define ADC_OFFSET 2044

// function prototypes
void integer_to_ascii(char str[50], uint32_t time);
void binary_to_ascii(char str[50], int buttons);
void float_to_ascii(char str[50], float cpu_load);
void get_waveform(void);
void draw_grid(void);
void draw_bar(void);
int fifo_put(int data);
int fifo_get(int *data);
#pragma FUNC_CANNOT_INLINE(cpu_load_count)
uint32_t cpu_load_count(void);

uint32_t gSystemClock; // [Hz] system clock frequency
volatile uint32_t gTime = 8345; // time in hundredths of a second

volatile uint16_t locoADCBuffer[LOCO_BUFFER_SIZE]; // circular buffer
tContext sContext; // for the display

// CPU load counters
uint32_t count_unloaded = 0;
uint32_t count_loaded = 0;
float cpu_load = 0.0;

// boolean if trigger is found
int triggered = 0;
// the value the trigger is looking for
int16_t trigger_val;
// the index of the trigger once found
int32_t trigger_index;

// the button press from the FIFO buffer
int button;
// the direction of the trigger
int trigger_direction = 1;
// voltage possibilities
float voltages[4] = {.1, .2, .5, 1};
int voltage_index = 1;
const char * const voltage_strs[] = {
                                     "100 mV", "200 mV", "500 mV", "  1  V"
};


int main(void) {
    IntMasterDisable();

    // Enable the Floating Point Unit, and permit ISRs to use it
    FPUEnable();
    FPULazyStackingEnable();

    // Initialize the system clock to 120 MHz
    gSystemClock = SysCtlClockFreqSet(SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN | SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480, 120000000);

    Crystalfontz128x128_Init(); // Initialize the LCD display driver
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP); // set screen orientation

    GrContextInit(&sContext, &g_sCrystalfontz128x128); // Initialize the grlib graphics context
    GrContextFontSet(&sContext, &g_sFontFixed6x8); // select font

    //uint32_t time;  // local copy of gTime
//    char str[50];   // string buffer
//    char bin[50];
    // full-screen rectangle
    tRectangle rectFullScreen = {0, 0, GrContextDpyWidthGet(&sContext)-1, GrContextDpyHeightGet(&sContext)-1};

    // interrupts
    ButtonInit();
    ADCInit();

    // calculate the CPU load
    // initialize timer 3 in one-shot mode for polled timing
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);
    TimerDisable(TIMER3_BASE, TIMER_BOTH);
    TimerConfigure(TIMER3_BASE, TIMER_CFG_ONE_SHOT);
    TimerLoadSet(TIMER3_BASE, TIMER_A, gSystemClock - 10000); // 10 milli sec interval

    count_unloaded = cpu_load_count();

    IntMasterEnable();

    count_loaded = cpu_load_count();
    cpu_load = 1.0f - (float)count_loaded/count_unloaded; // compute CPU load

    while (true) {
        float fScale = (VIN_RANGE * PIXELS_PER_DIV)/((1 << ADC_BITS) * voltages[voltage_index]); // EDIT HERE FOR VOLTAGE
        if (!triggered) {
            get_waveform();
        }

//        time = gTime; // read shared global only once
        int previous_y = LCD_VERTICAL_MAX/2 - (int)roundf(fScale * ((int)locoADCBuffer[0] - ADC_OFFSET));
        int pixel_y;
        int i;
        if (triggered) {
            GrContextForegroundSet(&sContext, ClrBlack);
            GrRectFill(&sContext, &rectFullScreen); // fill screen with black

            draw_grid();

            for (i = 0; i < 128; i++){
                pixel_y = LCD_VERTICAL_MAX/2 - (int)roundf(fScale * ((int)locoADCBuffer[i] - ADC_OFFSET));
                tRectangle pixel = {i, ((pixel_y+previous_y)/2), (i+1), (pixel_y+(pixel_y-previous_y)/2)};
                GrContextForegroundSet(&sContext, ClrYellow); // yellow text
                GrRectFill(&sContext, &pixel);
                previous_y = pixel_y;
            }

            draw_bar();

            GrFlush(&sContext); // flush the frame buffer to the LCD
            triggered = 0;
        }

//        if ((time%100) < 5){
//            triggered = 0;
//        }

        // read button buffer
        if(fifo_get(&button)){
            if(button == TRIGGER_UP){
                trigger_direction = 1;
            } else if(button == TRIGGER_DOWN){
                trigger_direction = 0;
            } else if(button == INCREASE_VOLT){
                if(voltage_index <= 2){
                    voltage_index++;
                }
            } else if(button == DECREASE_VOLT){
                if(voltage_index >= 1){
                    voltage_index--;
                }
            }
        }

//        // convert integers
//        integer_to_ascii(str, time); // convert the time
//        binary_to_ascii(bin, gButtons);
//
//        GrContextForegroundSet(&sContext, ClrYellow); // yellow text
//        GrStringDraw(&sContext, str, /*length*/ -1, /*x*/ 0, /*y*/ 0, /*opaque*/ false);
//        GrStringDraw(&sContext, bin, /*length*/ -1, /*x*/ 0, /*y*/ 15, /*opaque*/ false);
//        GrFlush(&sContext); // flush the frame buffer to the LCD
    }
}

void float_to_ascii(char str[50], float cpu_load){
    sprintf(str, "%f", cpu_load*100);
}

void integer_to_ascii(char str[50], uint32_t time){
    uint32_t ff, ff2, ss, ss2, mm, mm2;
    int i=0, j=7, flag=0;
    char temp_string[2];

    // ff
    ff = time % 10;
    time = time - ff;
    ff = ff + '0';
    sprintf(temp_string, "%c", ff);
    strcpy(str, temp_string);

    // ff2
    ff2 = (time % 100) / 10;
    time = time - (ff2 * 10);
    ff2 = ff2 + '0';
    sprintf(temp_string, "%c", ff2);
    strcat(str, temp_string);

    // :
    sprintf(temp_string, "%c", 58);
    strcat(str, temp_string);

    // ss
    ss = (time % 1000) / 100;
    time = time - (ss * 100);
    ss = ss + '0';
    sprintf(temp_string, "%c", ss);
    strcat(str, temp_string);

    // ss2
    ss2 = (time % 10000) / 1000;
    if(ss2 >= 6){
        flag = 1;
        ss2 = ss2 - 6;
    }
    time = time - (ss2 * 1000);
    ss2 = ss2 + '0';
    sprintf(temp_string, "%c", ss2);
    strcat(str, temp_string);

    // :
    sprintf(temp_string, "%c", 58);
    strcat(str, temp_string);

    // mm
    mm = (time % 100000) / 10000;
    if(flag){
        time = time - 6000 - (mm * 10000);
        if(mm == 9){
            flag = 1;
            mm = 0;
        } else {
            flag = 0;
            mm = mm + 1;
        }
    }
    mm = mm + '0';
    sprintf(temp_string, "%c", mm);
    strcat(str, temp_string);

    // mm2
    mm2 = (time % 1000000) / 100000;
    if(flag){
        time = time - 10000;
        mm2 = mm2 + 1;
    }
    time = time - (mm2 * 100000);
    mm2 = mm2 + '0';
    sprintf(temp_string, "%c", mm2);
    strcat(str, temp_string);

    // reverse
    while(i<=j){
        char temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}


void binary_to_ascii(char str[50], int buttons){
    int c, k;

    strcpy(str, "");

    for (c = 8; c >= 0; c--){
      k = buttons >> c;

      if (k & 1)
          strcat(str, "1");
      else
          strcat(str, "0");
    }
}

void get_waveform(void){
    // index for finding trigger
    int i = 0;
    // index for copying values into local buff
    int x = 0;
    // the ypixel
    // larger then the largest index value
    uint32_t found_trigger_index = 4096;
    // will be user set?
    trigger_val = 2054;


    // get the wave form we are looking for
    while(triggered == 0){
        // 64 values behind the value just written
        trigger_index = ADC_BUFFER_WRAP(gADCBufferIndex - 64);
        // check from trigger_index to "curr_value"
        for (i = trigger_index; i > trigger_index-64; i--){
            // trigger value found
            if(gADCBuffer[ADC_BUFFER_WRAP(i)] == trigger_val){
                // FOUND IT!!!!!
                triggered = 1;
                found_trigger_index = ADC_BUFFER_WRAP(i);
                break;
            }
        }
        if (triggered == 1) {
            // copy it all into the local buffer FAST
            for (x = found_trigger_index-64, i = 0; x < found_trigger_index+64; x++, i++){
                locoADCBuffer[i] = gADCBuffer[ADC_BUFFER_WRAP(x)];
            }
            // make sure it's the rising edge
            if(trigger_direction){ // if it's 1: rising edge
                if(locoADCBuffer[64] < locoADCBuffer[63]) {
                    // if the newer reading is less than the less reading
                    // that means it's reading a falling edge
                    triggered = 0;
                }
//                    else {
//                    // make sure its continuous
//                    for (i = 1; i < 128; i++){
//                        if (abs(locoADCBuffer[i]- locoADCBuffer[i-1]) > 150){
//                            triggered = 0;
//                        }
//                    }
//                }
            } else {
                if(locoADCBuffer[64] > locoADCBuffer[63]) {
                    // if its reading increasing values, this is a rising edge
                    triggered = 0;
                }
//                else {
//                    // make sure its continuous
//                    for (i = 1; i < 128; i++){
//                        if (abs(locoADCBuffer[i]- locoADCBuffer[i-1]) > 150){
//                            triggered = 0;
//                        }
//                    }
//                }
            }
        }
    }


}

void draw_grid(void) {
    int i = 0;
    // draw horozontal lines
    for(i = 4; i < LCD_VERTICAL_MAX; i+=20){
        tRectangle pixel = {0, i, LCD_HORIZONTAL_MAX, i+1};
        GrContextForegroundSet(&sContext, ClrDarkBlue); // yellow text
        GrRectFill(&sContext, &pixel);
    }

    // draw horozontal lines
    for(i = 4; i < LCD_HORIZONTAL_MAX; i+=20){
        tRectangle pixel = {i, 0, i+1, LCD_VERTICAL_MAX};
        GrContextForegroundSet(&sContext, ClrDarkBlue); // yellow text
        GrRectFill(&sContext, &pixel);
    }

    // draw crosshairs
    tRectangle verti = {64, 0, 65, LCD_VERTICAL_MAX};
    GrContextForegroundSet(&sContext, ClrBlue); // yellow text
    GrRectFill(&sContext, &verti);

    tRectangle horo = {0, 64, LCD_HORIZONTAL_MAX, 65};
    GrContextForegroundSet(&sContext, ClrBlue); // yellow text
    GrRectFill(&sContext, &horo);

}

void draw_bar(void){
    char cpu_load_string[50];

    // draw bar at the top
    tRectangle pixel = {0, 0, LCD_HORIZONTAL_MAX, 10};
    GrContextForegroundSet(&sContext, ClrBlack);
    GrRectFill(&sContext, &pixel);

    // draw time scale
    GrContextForegroundSet(&sContext, ClrWhite);
    GrStringDraw(&sContext, "20 us", /*length*/ -1, /*x*/ 0, /*y*/ 0, /*opaque*/ false);

    // draw voltage scale
    GrContextForegroundSet(&sContext, ClrWhite);
    GrStringDraw(&sContext, voltage_strs[voltage_index], /*length*/ -1, /*x*/ 50, /*y*/ 0, /*opaque*/ false);

    // draw trigger slope x1 y1 x2 y2
    tRectangle vert_bar = {110, 1, 110, 9};
    GrContextForegroundSet(&sContext, ClrWhite);
    GrRectFill(&sContext, &vert_bar);

    if(trigger_direction){
        tRectangle bottom_bar = {105, 9, 110, 9};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &bottom_bar);

        tRectangle top_bar = {110, 1, 115, 1};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &top_bar);

        // arrows
        tRectangle left_arrow_1 = {109, 5, 109, 5};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &left_arrow_1);

        tRectangle left_arrow_2 = {108, 6, 108, 6};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &left_arrow_2);

        tRectangle right_arrow_1 = {111, 5, 111, 5};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &right_arrow_1);

        tRectangle right_arrow_2 = {112, 6, 112, 6};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &right_arrow_2);
    } else {
        tRectangle bottom_bar = {105, 1, 110, 1};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &bottom_bar);

        tRectangle top_bar = {110, 9, 115, 9};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &top_bar);

        // arrows
        tRectangle left_arrow_1 = {108, 5, 108, 5};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &left_arrow_1);

        tRectangle left_arrow_2 = {109, 6, 109, 6};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &left_arrow_2);

        tRectangle right_arrow_1 = {112, 5, 112, 5};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &right_arrow_1);

        tRectangle right_arrow_2 = {111, 6, 111, 6};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &right_arrow_2);
    }
    // draw bar at the top
    tRectangle rect_bottom = {0, LCD_VERTICAL_MAX - 10, LCD_HORIZONTAL_MAX, LCD_VERTICAL_MAX};
    GrContextForegroundSet(&sContext, ClrBlack);
    GrRectFill(&sContext, &rect_bottom);

    // draw cpu load
    GrContextForegroundSet(&sContext, ClrWhite);
    GrStringDraw(&sContext, "CPU load = ", /*length*/ -1, /*x*/ 0, /*y*/ LCD_VERTICAL_MAX - 10, /*opaque*/ false);

    float_to_ascii(cpu_load_string, cpu_load);
    cpu_load_string[5] = '\0';

    GrContextForegroundSet(&sContext, ClrWhite);
    GrStringDraw(&sContext, cpu_load_string, /*length*/ -1, /*x*/ 63, /*y*/ LCD_VERTICAL_MAX - 10, /*opaque*/ false);

    GrContextForegroundSet(&sContext, ClrWhite);
    GrStringDraw(&sContext, "%", /*length*/ -1, /*x*/ 95, /*y*/ LCD_VERTICAL_MAX - 10, /*opaque*/ false);


}

uint32_t cpu_load_count(void) {
    uint32_t i = 0;
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER3_BASE, TIMER_A); // start one-shot timer
    while (!(TimerIntStatus(TIMER3_BASE, false) & TIMER_TIMA_TIMEOUT))
        i++;
    return i;
}
