/*
 * ECE 3849 Lab2 starter project
 *
 * Gene Bogdanov    9/13/2017
 */
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Mailbox.h>
#include <ti/sysbios/utils/Load.h>

/* DriverLib Header files */
#include "Crystalfontz128x128_ST7735.h"
#include "driverlib/systick.h"
#include "driverlib/fpu.h"
#include "driverlib/interrupt.h"

/* Random C Header files */
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

/* Our Header files */
#include "scope.h"
#include "buttons.h"
#include "kiss_fft.h"
#include "_kiss_fft_guts.h"
#include "pwm.h"


#include "driverlib/sysctl.h"
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_memmap.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"

#define LOCO_BUFFER_SIZE 128 // size must be a power of 2
#define LOCO_FFT_BUFFER_SIZE 1024 // size must be a power of 2
#define VIN_RANGE 3.3
#define PIXELS_PER_DIV 20
#define ADC_BITS 12
#define ADC_OFFSET 2044

#define TIME_DOMAIN 0
#define FREQUENCY_DOMAIN 1

#define PI 3.14159265358979f
#define NFFT 1024 // FFT length
#define KISS_FFT_CFG_SIZE (sizeof(struct kiss_fft_state)+sizeof(kiss_fft_cpx)*(NFFT-1))


// function prototypes
void get_waveform(void);
void draw_grid(void);
void draw_bar(void);
void get_fft_waveform(void);
float getLoad(void);
#pragma FUNC_CANNOT_INLINE(cpu_load_count)
uint32_t cpu_load_count(void);
void Timer0_ISR(UArg arg1, UArg uarg2);
void PWMInit(void);


// the direction of the trigger
int trigger_direction = 1;
// voltage possibilities
float voltages[4] = {.1, .2, .5, 1};
int voltage_index = 1;
const char * const voltage_strs[] = {
                                     "100 mV", "200 mV", "500 mV", "  1  V"
};

// CPU load counters
uint32_t count_unloaded = 0;
uint32_t count_loaded = 0;
float cpu_load = 0.0;

volatile uint16_t locoADCBuffer[LOCO_BUFFER_SIZE]; // circular buffer
volatile uint16_t locoFFTBuffer[LOCO_FFT_BUFFER_SIZE]; // circular buffer
volatile uint16_t processedBuffer[LOCO_BUFFER_SIZE]; // circular buffer
tContext sContext; // for the display

// boolean if trigger is found
int triggered = 0;
// the value the trigger is looking for
int16_t trigger_val;
// the index of the trigger once found
int32_t trigger_index;

// 0 for time domain
// 1 for frequency domain
int display_mode = TIME_DOMAIN;

uint32_t gSystemClock = 120000000; // [Hz] system clock frequency

volatile float cpuLoad = 0;

// measured event latencies in clock cycles
unsigned long button_task_latency = 0;
unsigned long waveform_task_latency = 0;
// measured event response time in clock cycles
unsigned long button_task_response_time = 0;
unsigned long waveform_task_response_time = 0;
// number of deadlines missed
unsigned long button_task_missed_deadlines = 0;
unsigned long waveform_task_missed_deadlines = 0;
// counts
unsigned long button_task_count = 0;
unsigned long waveform_task_count = 0;
uint32_t Timer0_elapsed = 0;
uint32_t Timer0_periods = 0;
static float total_frequency = 0;


#define SYSTEM_CLOCK_MHZ 120            // [MHz] system clock frequency
#define BUTTON_TASK_PERIOD 5000    // [us] event0 period                 // I HAVE NO IDEA IF THIS IS RIGHT
#define TIMER0_PERIOD (SYSTEM_CLOCK_MHZ * BUTTON_TASK_PERIOD)
#define WAVEFORM_TASK_PERIOD 5000    // [us] event0 period                 // I HAVE NO IDEA IF THIS IS RIGHT
#define TIMER1_PERIOD (SYSTEM_CLOCK_MHZ * WAVEFORM_TASK_PERIOD)

void clk1Fxn(UArg arg1, UArg arg2)
{
    /* Implicit posting of Event_Id_01 by Sempahore_post() */
    //cpuLoad = getLoad();
    Semaphore_post(BTN_CLK_SEM);
}

void freq1Fxn(UArg arg1, UArg arg2)
{
    /* Implicit posting of Event_Id_01 by Sempahore_post() */
    //cpuLoad = getLoad();
    Semaphore_post(FREQ_CLK_SEM);
}
void Timer0_ISR(UArg arg1, UArg uarg2){
    static uint32_t Timer0_previous = 0;
    TIMER0_ICR_R |= 6; // CAECINT | CAMCINT
    uint32_t Timer0_current = TimerValueGet(TIMER0_BASE, TIMER_A);
    Timer0_elapsed = Timer0_current - Timer0_previous;
    Timer0_periods++;
    Timer0_previous = Timer0_current;

}

void FREQ_TASK_FUNC(UArg arg1, UArg arg2) {
    while (true) {
        Semaphore_pend(FREQ_CLK_SEM, BIOS_WAIT_FOREVER);
        total_frequency = 10000.f * Timer0_elapsed / Timer0_periods;
        Timer0_periods = 0;
        Timer0_elapsed = 0;


        //cpuLoad = getCPULoad(); // remove me
    }
}

/*
 *  ======== main ========
 */
int main(void)
{
    IntMasterDisable();

    // EXTRA CREDIT
    // initialize general purpose timers 0-2 for periodic interrupts
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    TimerDisable(TIMER0_BASE, TIMER_BOTH);
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMER0_BASE, TIMER_A, TIMER0_PERIOD - 1);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntClear(TIMER0_BASE,  TIMER_TIMA_TIMEOUT);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
    TimerDisable(TIMER1_BASE, TIMER_BOTH);
    TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMER1_BASE, TIMER_A, TIMER1_PERIOD - 1);
    TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntClear(TIMER1_BASE,  TIMER_TIMA_TIMEOUT);

    // EXTRA CREDIT

    // Enable the Floating Point Unit, and permit ISRs to use it
    //FPUEnable();
    //FPULazyStackingEnable();

    // initialize SysTick timer for the purpose of profiling
   // SysTickPeriodSet(1 << 24); // full 24-bit counter
   // SysTickEnable();


    ButtonInit();
    ADCInit();
    PWMInit();
    // hardware initialization goes here
    Crystalfontz128x128_Init(); // Initialize the LCD display driver
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP); // set screen orientation

    GrContextInit(&sContext, &g_sCrystalfontz128x128); // Initialize the grlib graphics context
    GrContextFontSet(&sContext, &g_sFontFixed6x8); // select font

    //tRectangle rectFullScreen = {0, 0, GrContextDpyWidthGet(&sContext)-1, GrContextDpyHeightGet(&sContext)-1};


    // calculate the CPU load
    // initialize timer 3 in one-shot mode for polled timing
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);
    TimerDisable(TIMER3_BASE, TIMER_BOTH);
    TimerConfigure(TIMER3_BASE, TIMER_CFG_ONE_SHOT);
    TimerLoadSet(TIMER3_BASE, TIMER_A, gSystemClock/1000 - 1); // 10 milli sec interval

    count_unloaded = cpu_load_count();

    /* Start BIOS */
    BIOS_start();

    return (0);
}

void BTN_TASK_FUNC(UArg arg1, UArg arg2) // highest Priority!!
{
    IntMasterEnable();

    //unsigned long t;

    while (true) {
        if (Semaphore_pend(BTN_CLK_SEM, BIOS_WAIT_FOREVER)) {
            // EXTRA CREDIT
           // t = TIMER0_PERIOD - TIMER1_TAR_R;
           // if (t > button_task_latency) button_task_latency = t; // measure latency
            // EXTRA CREDIT

            ButtonISR(); // inside here
            button_task_count++;

            // EXTRA CREDIT
          //  if (Semaphore_getCount(BTN_CLK_SEM)) { // next event occurred
         //       button_task_missed_deadlines++;
         //       t = 2 * TIMER0_PERIOD; // timer overflowed since last event
         //   }
          //  else t = TIMER0_PERIOD;
          //  t -= TIMER1_TAR_R;
          //  if (t > button_task_response_time) button_task_response_time = t; // measure response time
            // EXTRA CREDIT
        }
    }
}

void USER_INPUT_TASK_FUNC(UArg arg1, UArg arg2) // medium priority!!
{
    IntMasterEnable();
    uint32_t presses = 0;

    while (true) {
        if (Mailbox_pend(BTN_PRESS_MAILBOX, &presses, BIOS_WAIT_FOREVER)) {
            if(presses){
                if(presses & 4){
                    trigger_direction = 1;
                } else if(presses & 8){
                    trigger_direction = 0;
                } else if(presses & 128){
                    if(voltage_index <= 2){
                        voltage_index++;
                    }
                } else if(presses & 256){
                    if(voltage_index >= 1){
                        voltage_index--;
                    }
                }else if(presses & 16){
                    display_mode = (display_mode+1) %2;
                }
            }
            presses = 0;
        }
    }
}

void DISPLAY_TASK_FUNC(UArg arg1, UArg arg2) // low Priority!!
{
    IntMasterEnable();

    int previous_y;
    int pixel_y;
    int i;
    tRectangle rectFullScreen = {0, 0, GrContextDpyWidthGet(&sContext)-1, GrContextDpyHeightGet(&sContext)-1};
    while (true) {
        if (Semaphore_pend(DISPLAY_SEM, BIOS_WAIT_FOREVER)) {
            count_loaded = cpu_load_count();
            cpu_load = (1.0f - (float)count_loaded/count_unloaded)*100.0; // compute CPU load


            GrContextForegroundSet(&sContext, ClrBlack);
            GrRectFill(&sContext, &rectFullScreen); // fill screen with black
            draw_grid();
            draw_bar();
            previous_y = processedBuffer[0];
            for (i = 0; i < 128; i++){
                pixel_y = processedBuffer[i];
                tRectangle pixel = {i, ((pixel_y+previous_y)/2), (i+1), (pixel_y+(pixel_y-previous_y)/2)};
                //tRectangle pixel = {i, (pixel_y), (i+1), (pixel_y+1)};
                GrContextForegroundSet(&sContext, ClrYellow); // yellow text
                GrRectFill(&sContext, &pixel);
                previous_y = pixel_y;
            }

            GrFlush(&sContext); // flush the frame buffer to the LCD

        }
    }
}

uint32_t start, finish, t, bias;
void WAVEFORM_TASK_FUNC(UArg arg1, UArg arg2) // high Priority!!
{
    IntMasterEnable();

   // start = SysTickValueGet(); // read SysTick timer value
   // finish = SysTickValueGet();
   // bias = (start - finish) & 0xffffff;

    while (true) {
        Semaphore_pend(WAVEFORM_SEM, BIOS_WAIT_FOREVER);

        // EXTRA CREDIT
      //  start = SysTickValueGet();
        // EXTRA CREDIT

        if (display_mode == TIME_DOMAIN){
            get_waveform();
        } else {
            get_fft_waveform();
        }

        // EXTRA CREDIT
      //  waveform_task_count++;

      //  finish = SysTickValueGet();
      //  t = ((start - finish) & 0xffffff) - bias;
      //  if (t > waveform_task_response_time) waveform_task_response_time = t; // measure response time
        // EXTRA CREDIT

        Semaphore_post(PROCESSING_SEM);
    }

}

void PROCESSING_TASK_FUNC(UArg arg1, UArg arg2) // lowest Priority!!
{
    IntMasterEnable();

    static char kiss_fft_cfg_buffer[KISS_FFT_CFG_SIZE]; // Kiss FFT config memory
    size_t buffer_size = KISS_FFT_CFG_SIZE;
    kiss_fft_cfg cfg; // Kiss FFT config
    static kiss_fft_cpx in[NFFT], out[NFFT]; // complex waveform and spectrum buffers
    int i;
    cfg = kiss_fft_alloc(NFFT, 0, kiss_fft_cfg_buffer, &buffer_size); // init Kiss FFT


    float fScale;
    int pixel_y;
    int j;

    while (true) {
        if (Semaphore_pend(PROCESSING_SEM, BIOS_WAIT_FOREVER)) {


            if (display_mode == TIME_DOMAIN) {
                fScale = (VIN_RANGE * PIXELS_PER_DIV)/((1 << ADC_BITS) * voltages[voltage_index]);
                for (j = 0; j < 128; j++){
                    pixel_y = LCD_VERTICAL_MAX/2 - (int)roundf(fScale * ((int)locoADCBuffer[j] - ADC_OFFSET));
                    processedBuffer[j] = pixel_y;
                }
            } else { // FREQUENCY_DOMAIN
                for (i = 0; i < NFFT; i++) {    // generate an input waveform
                    in[i].r = locoFFTBuffer[i]/4096.0f; // real part of waveform
                    //in[i].r = sinf(20*PI*i/NFFT);;
                    in[i].i = 0;                  // imaginary part of waveform
                }
                kiss_fft(cfg, in, out);         // compute FFT
                // convert first 128 bins of out[] to dB for display
                for (j = 0; j < 128; j++){
                    pixel_y = (20 - roundf(10.0f * log10f(out[j].r*out[j].r + out[j].i*out[j].i))) - 65480;
                    processedBuffer[j] = pixel_y;
                }
            }
            Semaphore_post(DISPLAY_SEM);
            Semaphore_post(WAVEFORM_SEM);
        }
    }
}

void get_fft_waveform(void){
    int x, i;
    int32_t check = getADCBufferIndex();
    for (x = ADC_BUFFER_WRAP(check-1024), i = 0; x < ADC_BUFFER_WRAP(check); x++, i++) {
        locoFFTBuffer[i] = gADCBuffer[ADC_BUFFER_WRAP(x)];
    }
}

void get_waveform(void){
    // index for finding trigger
    int i = 0;
    // index for copying values into local buff
    int x = 0;
    int triggered = 0;
    // larger then the largest index value
    uint32_t found_trigger_index = 4096;
    // will be user set?
    trigger_val = 2054;


    // get the wave form we are looking for
    while(triggered == 0){
        // 64 values behind the value just written
        trigger_index = ADC_BUFFER_WRAP(getADCBufferIndex() - 64);
        // check from trigger_index to "curr_value"
        for (i = trigger_index; i > trigger_index-64; i--){
            // trigger value found
            if(gADCBuffer[ADC_BUFFER_WRAP(i)] == trigger_val){
                // FOUND IT!!!!!
                triggered = 1;
                found_trigger_index = ADC_BUFFER_WRAP(i);
                break;
            }
        }
        if (triggered == 1) {

            // make sure it's the rising edge
            if(trigger_direction){ // if it's 1: rising edge
                if(gADCBuffer[ADC_BUFFER_WRAP(found_trigger_index-3)] < gADCBuffer[ADC_BUFFER_WRAP(found_trigger_index)]) {

                    // copy it all into the local buffer FAST
                    for (x = found_trigger_index-64, i = 0; x < found_trigger_index+64; x++, i++){
                        locoADCBuffer[i] = gADCBuffer[ADC_BUFFER_WRAP(x)];
                    }
                }
            } else {
                if(gADCBuffer[ADC_BUFFER_WRAP(found_trigger_index-3)] > gADCBuffer[ADC_BUFFER_WRAP(found_trigger_index)]) {
                    // copy it all into the local buffer FAST
                    for (x = found_trigger_index-64, i = 0; x < found_trigger_index+64; x++, i++){
                        locoADCBuffer[i] = gADCBuffer[ADC_BUFFER_WRAP(x)];
                    }
                }
            }
        }
    }
}

void draw_grid(void) {
    int i = 0;
    // draw horozontal lines
    for(i = 4; i < LCD_VERTICAL_MAX; i+=20){
        tRectangle pixel = {0, i, LCD_HORIZONTAL_MAX, i+1};
        GrContextForegroundSet(&sContext, ClrDarkBlue); // yellow text
        GrRectFill(&sContext, &pixel);
    }

    // draw horozontal lines
    for(i = 4; i < LCD_HORIZONTAL_MAX; i+=20){
        tRectangle pixel = {i, 0, i+1, LCD_VERTICAL_MAX};
        GrContextForegroundSet(&sContext, ClrDarkBlue); // yellow text
        GrRectFill(&sContext, &pixel);
    }

    // draw crosshairs
    tRectangle verti = {64, 0, 65, LCD_VERTICAL_MAX};
    GrContextForegroundSet(&sContext, ClrBlue); // yellow text
    GrRectFill(&sContext, &verti);

    tRectangle horo = {0, 64, LCD_HORIZONTAL_MAX, 65};
    GrContextForegroundSet(&sContext, ClrBlue); // yellow text
    GrRectFill(&sContext, &horo);

}

float getLoad(void) {
    Load_Stat swiLoad, hwiLoad, taskLoad, oneTaskLoad;
    Load_getGlobalHwiLoad(&hwiLoad);
    Load_getGlobalSwiLoad(&swiLoad);
    Task_Handle th = Task_Object_first();
    while (th) {
        Load_getTaskLoad(th, &oneTaskLoad);
        taskLoad.totalTime = (taskLoad.totalTime > oneTaskLoad.totalTime ? taskLoad.totalTime : oneTaskLoad.totalTime);
        taskLoad.threadTime += oneTaskLoad.threadTime;
    }
    if (taskLoad.totalTime == 0) taskLoad.totalTime = 1;
    if (swiLoad.totalTime == 0) swiLoad.totalTime = 1;
    if (hwiLoad.totalTime == 0) hwiLoad.totalTime = 1;

    float fswiLoad = (float)swiLoad.threadTime / swiLoad.totalTime;
    float fhwiLoad = (float)hwiLoad.threadTime / hwiLoad.totalTime;
    float ftaskLoad = (float)taskLoad.threadTime / taskLoad.totalTime;

    return fswiLoad + fhwiLoad + ftaskLoad;
}

void draw_bar(void){
    char str[20];
    // draw bar at the top
    tRectangle pixel = {0, 0, LCD_HORIZONTAL_MAX, 10};
    GrContextForegroundSet(&sContext, ClrBlack);
    GrRectFill(&sContext, &pixel);

    // draw time scale
    GrContextForegroundSet(&sContext, ClrWhite);
    GrStringDraw(&sContext, "20 us", /*length*/ -1, /*x*/ 0, /*y*/ 0, /*opaque*/ false);

    // draw voltage scale
    GrContextForegroundSet(&sContext, ClrWhite);
    GrStringDraw(&sContext, voltage_strs[voltage_index], /*length*/ -1, /*x*/ 50, /*y*/ 0, /*opaque*/ false);

    // draw trigger slope x1 y1 x2 y2
    tRectangle vert_bar = {110, 1, 110, 9};
    GrContextForegroundSet(&sContext, ClrWhite);
    GrRectFill(&sContext, &vert_bar);

    if(trigger_direction){
        tRectangle bottom_bar = {105, 9, 110, 9};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &bottom_bar);

        tRectangle top_bar = {110, 1, 115, 1};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &top_bar);

        // arrows
        tRectangle left_arrow_1 = {109, 5, 109, 5};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &left_arrow_1);

        tRectangle left_arrow_2 = {108, 6, 108, 6};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &left_arrow_2);

        tRectangle right_arrow_1 = {111, 5, 111, 5};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &right_arrow_1);

        tRectangle right_arrow_2 = {112, 6, 112, 6};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &right_arrow_2);
    } else {
        tRectangle bottom_bar = {105, 1, 110, 1};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &bottom_bar);

        tRectangle top_bar = {110, 9, 115, 9};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &top_bar);

        // arrows
        tRectangle left_arrow_1 = {108, 5, 108, 5};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &left_arrow_1);

        tRectangle left_arrow_2 = {109, 6, 109, 6};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &left_arrow_2);

        tRectangle right_arrow_1 = {112, 5, 112, 5};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &right_arrow_1);

        tRectangle right_arrow_2 = {111, 6, 111, 6};
        GrContextForegroundSet(&sContext, ClrWhite);
        GrRectFill(&sContext, &right_arrow_2);
    }

    // print the cpu load
    snprintf(str, sizeof(str), "CPU Load: %.2f %%", cpu_load);
    GrStringDraw(&sContext, str, -1, 0, 110, false);

    // print the frequency count
    snprintf(str, sizeof(str), "f = %.3f Hz", total_frequency);
    GrStringDraw(&sContext, str, -1, 0, 120, false);
}

uint32_t cpu_load_count(void) {
    uint32_t i = 0;
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER3_BASE, TIMER_A); // start one-shot timer
    while (!(TimerIntStatus(TIMER3_BASE, false) & 0x0000001))
        i++;
    return i;
}
