
#ifndef PWM_H_
#define PWM_H_

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/Timestamp.h>
#include <xdc/runtime/Types.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Mailbox.h>
#include <ti/sysbios/utils/Load.h>

/* DriverLib Header files */
#include "Crystalfontz128x128_ST7735.h"
#include "driverlib/systick.h"
#include "driverlib/fpu.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/timer.h"
#include "driverlib/interrupt.h"
#include "driverlib/comp.h"
#include "driverlib/pin_map.h"
#include "driverlib/udma.h"
#include "driverlib/pwm.h"

/* INC Header files */
#include "inc/tm4c1294ncpdt.h"
#include "inc/hw_memmap.h"

/* Random C Header files */
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

#define M_PI 3.14159265358979323f
#define PWM_PERIOD 258 // PWM period = 2^8 + 2 system clock cycles


#endif /* PWM_H_ */
